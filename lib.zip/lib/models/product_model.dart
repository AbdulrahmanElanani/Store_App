class ProductModel {
  final int id;
  final String title;
  final double price;
  final String description;
  final String category;
  final String image;
  final RatingModel raiting;

  ProductModel(
      {required this.id,
      required this.title,
      required this.price,
      required this.description,
      required this.category,
      required this.image,
      required this.raiting});

  factory ProductModel.fromJosn(josnData) {
    return ProductModel(
        id: josnData['id'],
        title: josnData['title'],
        price: josnData['price'],
        description: josnData['description'],
        category: josnData['category'],
        image: josnData['image'],
        raiting: RatingModel.fromJosn(josnData['rating']));
  }
}

class RatingModel {
  final double rate;
  final int count;

  RatingModel({required this.rate, required this.count});
  factory RatingModel.fromJosn(josnData) {
    return RatingModel(rate: josnData['rate'], count: josnData['count']);
  }
}
